package com.SmartBudget.SmartBudget;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartBudgetApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartBudgetApplication.class, args);
	}

}
